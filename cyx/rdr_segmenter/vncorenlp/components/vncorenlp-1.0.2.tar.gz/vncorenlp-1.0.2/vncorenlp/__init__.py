#!/usr/bin/python
# -*- coding: utf-8 -*-
from .vncorenlp import VNCORENLP_SERVER
from .vncorenlp import VnCoreNLP
